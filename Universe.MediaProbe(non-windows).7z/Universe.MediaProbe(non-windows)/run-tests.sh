#!/bin/bash
rm ump-tests.7z
rm -r ump-tests
wget -O ump-tests.7z 'https://www.dropbox.com/s/9cv9rgzrxjaeya1/ump-tests.7z?dl=1'
# curl -k -L -o ump-tests.7z https://www.dropbox.com/s/3yst5jxsrjbddvb/ump-tests.7z?dl=1

7za x -y ump-tests.7z
rm ump-tests.7z

cd ump-tests
nu-c Universe.MediaProbe.Tests.dll
cd ..
